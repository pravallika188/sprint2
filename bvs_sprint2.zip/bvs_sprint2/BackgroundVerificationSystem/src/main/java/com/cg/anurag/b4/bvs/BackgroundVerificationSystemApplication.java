package com.cg.anurag.b4.bvs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackgroundVerificationSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackgroundVerificationSystemApplication.class, args);
	}

}
