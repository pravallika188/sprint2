package com.cg.anurag.b4.bvs.dao;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.anurag.b4.bvs.dto.Address;
public interface AddressDAO extends JpaRepository<Address,Integer>
{
    
}
